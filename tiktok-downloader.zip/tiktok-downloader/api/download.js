import axios from "axios";
import * as cheerio from "cheerio";

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Use POST method" });
  }

  try {
    const { url } = req.body;

    if (!url) return res.json({ error: "URL tidak boleh kosong!" });

    const response = await axios.get(url, {
      headers: { "User-Agent": "Mozilla/5.0" }
    });

    const $ = cheerio.load(response.data);

    const video = $('meta[property="og:video"]').attr("content");

    if (!video) {
      return res.json({ error: "Tidak bisa mendapatkan video!" });
    }

    return res.json({
      status: "success",
      download_url: video
    });

  } catch (err) {
    return res.json({ error: "Server error!" });
  }
}
